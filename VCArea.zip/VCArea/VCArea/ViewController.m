//
//  ViewController.m
//  VCArea
//
//  Created by zhang on 16/3/14.
//  Copyright © 2016年 Messcat. All rights reserved.
//

#import "ViewController.h"
#import "SelectAreaView.h"

#define getImageColor(n) [UIColor colorWithPatternImage:[UIImage imageNamed:n]]
#define AppBgImage getImageColor(@"appBg")
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = AppBgImage;
    SelectAreaView* areaView = [[SelectAreaView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.frame) - 216, CGRectGetWidth(self.view.frame), 216) type:AreaTypeArea];
    [self.view addSubview:areaView];
    
    areaView.leftClickAction = ^(){
        
    };
    areaView.rightClickAction = ^(NSString *areaString){
        
        NSLog(@"area______ %@",areaString);
    };
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
